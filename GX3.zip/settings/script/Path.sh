#!/system/bin/sh
# shellcheck disable=SC2034
# shellcheck disable=SC2154
# shellcheck disable=SC3043
# shellcheck disable=SC2155
# shellcheck disable=SC2046
# shellcheck disable=SC3045
zips="$MODPATH"/prebuilts/zip
key_select() {
    key_pressed=""
    while true; do
        local output=$(/system/bin/getevent -qlc 1)
        local key_event=$(echo "$output" | awk '{ print $3 }' | grep 'KEY_')
        local key_status=$(echo "$output" | awk '{ print $4 }')
        if echo "$key_event" | grep -q 'KEY_' && [ "$key_status" = "DOWN" ]; then
            key_pressed="$key_event"
            break
        fi
    done
    while true; do
        local output=$(/system/bin/getevent -qlc 1)
        local key_event=$(echo "$output" | awk '{ print $3 }' | grep 'KEY_')
        local key_status=$(echo "$output" | awk '{ print $4 }')
        if [ "$key_event" = "$key_pressed" ] && [ "$key_status" = "UP" ]; then
            break
        fi
    done
}
Aurora_ui_print() {
    sleep 0.02
    echo "[${OUTPUT}] $1"
}

Aurora_abort() {
    echo "[${ERROR_TEXT}] $1"
    abort "$ERROR_CODE_TEXT: $2"
}
Aurora_test_input() {
    if [ -z "$3" ]; then
        Aurora_ui_print "$1 ( $2 ) $WARN_MISSING_PARAMETERS"
    fi
}
print_title() {
    if [ -n "$2" ]; then
        Aurora_ui_print "$1 $2"
    fi
}
ui_print() {
    if [ "$1" = "- Setting permissions" ]; then
        return
    fi
    if [ "$1" = "- Extracting module files" ]; then
        return
    fi
    if [ "$1" = "- Current boot slot: $SLOT" ]; then
        return
    fi
    if [ "$1" = "- Device is system-as-root" ]; then
        return
    fi
    if [ "$(echo "$1" | grep -c '^ - Mounting ')" -gt 0 ]; then
        return
    fi
    if [ "$1" = "- Done" ]; then
        return
    fi
    echo "$1"
}
#About_the_custom_script
###############
App_data_patch_set_permissions() {
    Aurora_test_input "App_data_patch_set_permissions" "1" "$1"
    Aurora_test_input "App_data_patch_set_permissions" "2" "$2"
    patch_default "$MODPATH" "$2" "$SDCARD/Android/data/$1/"
    uid=$(pm dump "$1" | grep 'userId=' | awk -F'=' '{print $2}')
    chown -R "$uid":1078 "$SDCARD/Android/data/$1/"
}
mv_adb() {
    Aurora_test_input "mv_adb" "1" "$1"
    su -c mv "$MODPATH/$1"/* "/data/adb/"
}
aurora_flash_boot() {
    Aurora_test_input "aurora_flash_boot" "1" "$1"
    get_flags
    find_boot_image
    flash_image "$1" "$BOOTIMAGE"
}
magisk_denylist_add() {
    Aurora_test_input "magisk_denylist_add" "1" "$1"
    if [ -z "$KSU" ] && [ -z "$APATCH" ] && [ -n "$MAGISK_VER_CODE" ]; then
        magisk --denylist add "$1" >/dev/null 2>&1
    fi
}
set_permissions_755() {
    Aurora_test_input "set_permissions_755" "1" "$1"
    set_perm "$1" 0 0 0755
}
check_network() {
    ping -c 1 www.Google.com >/dev/null 2>&1
    local google_status=$?
    ping -c 1 github.com >/dev/null 2>&1
    local github_status=$?
    ping -c 1 google.com >/dev/null 2>&1
    local google_status=$?
    if [ $google_status -eq 0 ]; then
        Aurora_ui_print "$INTERNET_CONNET (Google)"
        Internet_CONN=3
    elif [ $github_status -eq 0 ]; then
        Aurora_ui_print "$INTERNET_CONNET (GitHub)"
        Internet_CONN=2
    elif [ $baidu_status -eq 0 ]; then
        Aurora_ui_print "$INTERNET_CONNET (Baidu.com)"
        Internet_CONN=1
    else
        Internet_CONN=
    fi
}

    cat "$wget_response_file" | tr -d '\n' | \
    sed 's/.*"assets":\[//' | sed 's/\].*//' | \
    tr '}' '\n' | \
    grep "$SEARCH_CHAR" | \
    awk -F'"browser_download_url":"' '{print $2}' | \
    sed 's/".*//' > "$TEMP_FILE"

    # 检查是否成功提取
    if [ ! -s "$TEMP_FILE" ]; then
        rm -f "$wget_response_file" "$TEMP_FILE"
        Aurora_ui_print "$NOTFOUND_URL"
        return 1
    fi

    DESIRED_DOWNLOAD_URL=$(cat "$TEMP_FILE")
    if [ -z "$DESIRED_DOWNLOAD_URL" ]; then
        rm -f "$wget_response_file" "$TEMP_FILE"
        Aurora_ui_print "$NOTFOUND_URL"
        return 1
    fi

    Aurora_ui_print "$DESIRED_DOWNLOAD_URL"
    rm -f "$wget_response_file" "$TEMP_FILE"
    return 0
}
