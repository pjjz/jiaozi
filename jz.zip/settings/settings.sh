# 脚本配置参数

# 模块存储的基础路径
# MODPATH

print_languages="zh"
# 默认打印的语言
# 各个目录的路径定义
ZIPLIST="/files/modules"
# zip模块存储的目录
PATCHDATA="/files/patches/data"
# 补丁DATA存储的目录
PATCHSDCARD="/files/patches/sdcard"
# 补丁sdcard存储的目录
PATCHAPK="/files/patches/apks"
# 安装APK存储的目录（非系统应用）
SDCARD="/storage/emulated/0"
# 用户态sdcard路径
PATCHMOD="/files/patches/modules"
# 补丁模块存储的目录
CustomScriptPath="/settings/custom_script.sh"
# 自定义脚本的路径
langpath="/settings/languages.ini"
# 语言设置文件路径
script_path="/settings/script/Path.sh"
# 脚本路径文件路径
download_destination="/$SDCARD/Download/AuroraNasa_Installer"
# 下载路径
max_retries="0"
# 下载重试次数

# 高级设置
Confirm_installation=false
# 安装前确认
install=false
# 是否安装模块
Download_before_install=false
# 是否在安装模块之前从网络下载模块并安装
Installer_Compatibility=false
# 是否启用兼容模式安装模块（非必要时不建议开启）
Installer_Log=true
# 是否记录安装模块的日志
CustomScript=true
# 是否启用自定义脚本
fix_ksu_install=false
# 尝试修复KernelSU可能会出现的安装问题（非必要时不建议开启，开启会减慢运行速度，并且可能会出现未知问题）
delete_download_files=false
# 删除下载的文件

# 用户自定义变量区域（可根据需要添加更多变量）

# Magisk及相关组件的版本要求
magisk_min_version="25400"
# 要求的Magisk最低版本
ksu_min_version="11300"
# 要求的KernelSU最低兼容版本
ksu_min_kernel_version="11300"
# 要求的KernelSU最低兼容内核版本
ksu_min_normal_version="12018"
# 要求的KernelSU常规使用最低版本
apatch_min_version="10657"
# 要求的APatch最低兼容版本
apatch_min_normal_version="10832"
# 要求的APatch常规使用最低版本
ANDROID_API="26"
# 要求的最低安卓API版本

#下载链接 （可根据需要添加更多链接）
LINKS_1=""
LINKS_2=""